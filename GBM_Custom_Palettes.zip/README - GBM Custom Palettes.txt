Game Boy Metallics Custom Palettes
by mugwomp93

These palette files are intended to be used with the corresponding overlays from my Game Boy Metallics collection.

*****TO USE THE CUSTOM PALETTES*****

	- Copy the palettes folder from GBM_Custom_Palettes.zip to your BIOS folder

		- If you're using 2 SD cards, this may be on SD1 or SD2 depending on your CFW:

			- For Garlic OS, copy it to the BIOS folder on SD2

			- For muOS, copy it to the BIOS folder on SD1 (/mnt/mmc/MUOS/bios/)

		- The included default.pal file is for the DMG color scheme
	
			- If you wish to use a different color scheme, make a copy of the palette file for the scheme you want to use and rename it/overwrite default.pal

Note that there's no option to specify which custom palette to use in Retroarch (i.e., it only uses default.pal), so you can only use one custom palette at a time.** Copying additional palettes folder(s) to your BIOS folder will overwrite the previous default.pal file.



Retroarch Settings:		

	- Quick Menu > Core Options

		GB Colorization: Custom

		Color Correction: OFF



-------------------------------------

**There is a workaround for this:

CAUTION: THIS PROCESS USES DINGUX COMMANDER, WHICH ALLOWS YOU TO MOVE, MODIFY, AND DELETE FILES ON YOUR SD CARD. IT HAS THE POTENTIAL TO SERIOUSLY MESS UP AND/OR ERASE YOUR FILES IF YOU DON'T KNOW WHAT YOU'RE DOING. FOLLOW THESE INSTRUCTIONS AT YOUR OWN RISK.

To get access to all of the custom palettes on your device, rename the various palette files (e.g., DMG.pal, GBP.pal, GBL.pal, etc) prior to copying them all to the palettes folder. Make sure to also include a copy named default.pal for whichever palette you wish to use first. Then, whenever you want to switch palettes, use Dingux Commander to make a copy of the new palette and rename it to default.pal (you'll need to either overwrite the previous default.pal or delete it prior to this).

For example, if you've used my naming scheme and you want to switch to GBP.pal:

	- Open Dingux Commander (for muOS, press A again after opening - it's not really frozen)

	- In the left directory, navigate to the palettes folder

	- Select GBP.pal and press X

		- Copy GBP.pal to the right directory

	- Select the copy of GBP.pal in the right directory and press X

		- Rename to default.pal

	- Press X again

		- Move default.pal to the left directory

		- A prompt indicating that the file already exists will pop up if default.pal is already present

			- Select YES to overwrite

	- Press Y and select Quit to exit Dingux Commander

Dingux Commander is included in the applications section of muOS and can be downloaded for Garlic OS from RG35XX.com (https://www.rg35xx.com/en/apps/apps-for-garlicos/).
