Perfect GBA Overlays for muOS 11

These files are adapted for muOS 11 (Beans) from u/1playerinsertcoin's Perfect GBA overlay for the Miyoo Mini Plus (https://www.reddit.com/r/MiyooMini/comments/18ovuld/i_made_a_game_boy_advance_overlay/?rdt=52022). All credit goes to them - my only contributions are the borders on the _mugwomp93 overlays. As the screen on the RG35XX Plus is darker than the original and the Miyoo Mini, I've only included the "bright" version of this overlay. Please refer to the original post for files and settings for the MM+, including Onion OS color correction settings not included here.

Note that these overlays have been tested on the RG35XX Plus with muOS 11. I have no idea how they look on other RG35XX-series devices (presumably the same?) or with different firmware.

******

As mentioned, the zip only includes bright version of the Perfect GBA grid. This version isn't quite as dark as the optimized version, though this comes at the expense of accuracy. I've also included _75 versions where the grid has been reduced to 75% opacity to help further increase brightness, though this further reduces accuracy. If you find the _75 version is still too dark, you could customize the overlay by adjusting the opacity of the _noframe version below 75% and then applying your preferred _nogrid version (i.e., borders and shadow only) over top in Photoshop, GIMP, etc.

To apply the overlay:

1. Quick Menu > On-Screen Overlay

   Display Overlay > ON

   Overlay Preset...
     - Select <Parent Directory> (I believe x2) to navigate to the main Overlays folder (you should see AntiKk, Jeltron, Perfect, and Stock folders)
     - Perfect > Perfect_GBA
     - Select your preferred overlay:
          - _noframe indicates just the grid with no logos, shadows, etc.
          - _nogrid indicates just the borders and shadow with no grid
          - _noshadow indicates border decorations but no shadows
          - all other naming conventionss indicate different border decorations

   Overlay Opacity > 1.00

2. Quick Menu > Core Options:

    Color Correction > OFF

    Interframe Blending	> ON (NOTE: If you don't like the image ghosting, turn it OFF, but you may see flickering elements in games.)

    Manage Core Options > Save Content Directory Options


3. Main Menu (press B to back out of Quick Menu) > Settings > Video > Scaling

   - Turn Integer Scale ON
   - Set Aspect Ratio to Custom
   - Set aspect ratio:
         - Custom Aspect Ratio (Width) > 640
         - Custom Aspect Ratio (Height) > 427
   - Turn Integer Scale OFF

   (This moves the image to the top of the screen instead of having it centered)

   Your final Scaling settings should be:

         Integer Scale				OFF

         Integer Scale Overscale		OFF

         Aspect Ratio 				Custom
         
         Custom Aspect Ratio (X Position) 	0
         
         Custom Aspect Ratio (Y Position) 	0
         
         Custom Aspect Ratio (Width) 		640
         
         Custom Aspect Ratio (Height) 		427

         Bilinear Filtering 			OFF

         Crop Overscan 				OFF


4. Quick Menu > Shaders:

   Video Shaders ON

   I've been using:
         
        Shader #0: interpolation > shaders > sharpen-bilinear.glsl 

   with default shader passes, filter, and scale but I'm new to shaders and haven't done a thorough testing to see what looks best.


Once you've got everything configured the way you want it, go to:

    Quick Menu > Overrides > Save Content Directory Overrides
 
to save your settings.

***Note that these are DARK overlays. You'll need to increase the screen brightness to maximum for them to be usable (menu + volume up, or in Configuration > General Settings in the muOS menu).***

There's a lot of interesting discussion in the comments of the Reddit post - I highly recommend reading through them if you're interested in the technical details and process that were used to create these overlays.

-mugwomp93