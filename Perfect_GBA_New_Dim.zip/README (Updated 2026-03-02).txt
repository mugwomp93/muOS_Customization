Perfect Overlays (Instructions for muOS included)

Updated 2026-03-02:
- updated for the new Perfect GBA overlays set

Updated 2025-04-04:
- updated GBA scaling settings for muOS Pixie (Retroarch 1.20.0?)

Updated 2025-03-12:
- updated recommended DMG/GBP and GBA shaders and settings

Updated 2025-01-08:
- clarified that custom palettes for DMG/GBP may need to be copied to TF2 if muOS has been migrated to SD2

Updated 2024-12-30:
- fixed minor visual artifact in some GBP overlays

Updated 2024-09-14:
- changed DMG, GBP, GBC grids for correct horizontal resolution (533px instead of 532px)
- added improved DMG, GBP, and GBA bezel shadows
- added a few more no grid, no shadow, etc options
- added a few more border designs
- restructured folders to make the choices less overwhelming/difficult to navigate
- (marginally) shorter names

*****

This is a collection of 1playerinsertcoin's Perfect overlays for GBA bundled with instructions for muOS. I've added my own borders, but the grids and magic are all theirs. You can check out all of their overlays, including overlays for CRT, GG, Lynx, and Apotris, on their Reddit profile: https://www.reddit.com/user/1playerinsertcoin/submitted/

My files for the original RG35XX with Garlic OS are on my Garlic OS Github repository (https://github.com/mugwomp93/GarlicOS_Customization).

Note that these overlays have only been tested on the RG35XX Plus and RG40XXV with muOS. I have no idea how they look on other devices or with different firmware. Given the differences I've seen so far ymmv (i.e., compared three devices, all three slightly different).

To use these overlays:

     1. Copy the "Perfect" folder to:

        /mnt/mmc/MUOS/retroarch/overlays

     2. See the README file in the relevant subfolder (Perfect_GBA_new) for system-specific settings

- mugwomp93